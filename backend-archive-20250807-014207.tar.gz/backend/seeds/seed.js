// Script de seed (exemple générique)
import sequelize from '../config/database.js';

(async () => {
  // Ajoutez ici vos seeds
  process.exit(0);
})();
