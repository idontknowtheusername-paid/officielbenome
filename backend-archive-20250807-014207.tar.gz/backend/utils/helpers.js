// Fonctions utilitaires génériques
export const toSlug = (str) => str.toLowerCase().replace(/\s+/g, '-');
